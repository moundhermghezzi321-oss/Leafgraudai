let selectedFile = null;
let cameraStream = null;

const imageInput = document.getElementById("imageInput");
const preview = document.getElementById("preview");
const cameraBox = document.getElementById("cameraBox");
const video = document.getElementById("video");
const canvas = document.getElementById("canvas");

if (imageInput) {
    imageInput.addEventListener("change", function () {
        selectedFile = this.files[0];
        if (selectedFile) {
            preview.src = URL.createObjectURL(selectedFile);
            preview.style.display = "block";
        }
    });
}

async function openCamera() {
    cameraBox.style.display = "block";
    try {
        cameraStream = await navigator.mediaDevices.getUserMedia({ video: true });
        video.srcObject = cameraStream;
    } catch (e) {
        alert("Camera access failed. On internet, camera needs HTTPS.");
    }
}

function captureImage() {
    const ctx = canvas.getContext("2d");
    canvas.width = video.videoWidth;
    canvas.height = video.videoHeight;
    ctx.drawImage(video, 0, 0);

    canvas.toBlob(function (blob) {
        selectedFile = new File([blob], "camera.jpg", { type: "image/jpeg" });
        preview.src = URL.createObjectURL(selectedFile);
        preview.style.display = "block";
    }, "image/jpeg");

    if (cameraStream) {
        cameraStream.getTracks().forEach(track => track.stop());
    }

    cameraBox.style.display = "none";
}

function analyzeImage() {
    if (!selectedFile) {
        alert("Choose or capture image first.");
        return;
    }

    const formData = new FormData();
    formData.append("image", selectedFile);

    document.getElementById("disease").innerText = "Analyzing...";

    fetch("/predict", {
        method: "POST",
        body: formData
    })
        .then(res => res.json())
        .then(data => {
            if (data.error) {
                alert(data.error);
                return;
            }

            document.getElementById("historyId").value = data.history_id;
            document.getElementById("msgDisease").value = data.disease;

            document.getElementById("disease").innerText = data.disease;
            document.getElementById("confidence").innerText = data.confidence + "%";
            document.getElementById("details").innerText = data.details;
            document.getElementById("advice").innerText = data.advice;
            document.getElementById("treatment").innerText = data.treatment;
        })
        .catch(() => alert("Prediction failed."));
}

function sendExpertMessage() {
    const disease = document.getElementById("msgDisease").value;
    const message = document.getElementById("expertMessage").value;
    const historyId = document.getElementById("historyId").value;

    if (!disease || !message) {
        alert("Write disease and message.");
        return;
    }

    const formData = new FormData();
    formData.append("disease", disease);
    formData.append("message", message);
    formData.append("history_id", historyId);

    fetch("/send-message", {
        method: "POST",
        body: formData
    })
        .then(res => res.json())
        .then(data => {
            if (data.success) {
                alert("Message sent to expert.");
                location.reload();
            } else {
                alert("Message failed.");
            }
        });
}
